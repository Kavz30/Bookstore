package com.example.demo.Controller;

import com.example.demo.Entity.Register;
import com.example.demo.Entity.Userdetails;
import com.example.demo.Repoistory.RegisterRepository;
import com.example.demo.Repoistory.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

@Controller
public class Controllers {

    @Autowired
    UserRepository userRepository;

    @Autowired
    RegisterRepository registerRepository;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @RequestMapping("/Aboutus")
    public String about() {
        return "About";
    }

    @RequestMapping("validateuser")
    public String validate(Register register, HttpSession session) {

        Register regis = registerRepository.findByEmailId(register.getEmailId());
        if (regis.getPassword().equals(register.getPassword())) {
            session.setAttribute("register", register);
            Register regi = (com.example.demo.Entity.Register) session.getAttribute("register");
            regi.getName();
            return "profile";
        }

        else {

            return "account";
        }

    }

    @RequestMapping("/signinuser")
    public String signin() {
        return "account";
    }

    @RequestMapping("/registeruser")
    public String Register(Register register) {
        System.out.println(register.toString());
        registerRepository.save(register);

        return "index";
    }

    @RequestMapping("/signupuser")
    public String signupuser() {
        return "Register";
    }

}