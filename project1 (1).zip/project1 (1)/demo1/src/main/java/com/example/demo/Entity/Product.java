package com.example.demo.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import java.beans.JavaBean;

import javax.persistence.*;

@Entity
public class Product {
    @ManyToOne
    @Autowired
    Product product;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long productid;
    String productname;
    String productdesc;
    double productprize;
    String productimg;

    public Long getProductid() {
        return productid;
    }

    public void setProductid(Long productid) {
        this.productid = productid;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getProductdesc() {
        return productdesc;
    }

    public void setProductdesc(String productdesc) {
        this.productdesc = productdesc;
    }

    public double getProductprize() {
        return productprize;
    }

    public void setProductprize(double productprize) {
        this.productprize = productprize;
    }

    public String getProductimg() {
        return productimg;
    }

    public void setProductimg(String productimg) {
        this.productimg = productimg;
    }

    @Override
    public String toString() {
        return "Product [productdesc=" + productdesc + ", productid=" + productid + ", productimg=" + productimg
                + ", productname=" + productname + ", productprize=" + productprize + "]";
    }

}
