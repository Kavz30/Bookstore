package com.example.demo.Controller;

import java.util.List;

import com.example.demo.Entity.Product;
import com.example.demo.Repoistory.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

@Controller
public class prodcutController {

    @Autowired
    ProductRepository productRepository;
    ModelAndView modelAndView=new ModelAndView();

    @RequestMapping("/productpage")
    public ModelAndView product() {

        List<Product> productList = (List<Product>) productRepository.findAll();
        modelAndView.addObject("product", productList);
        modelAndView.setViewName("read");

        return modelAndView;
    }

}
