package com.example.demo.Repoistory;

import java.util.List;

import com.example.demo.Entity.Product;

import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product, Integer> {

    public List<Product> findAll();
}
